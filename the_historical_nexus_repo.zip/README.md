# The Historical Nexus

Minimal scaffold. Replace AIHistoryAdvanced.jsx with your full game component.